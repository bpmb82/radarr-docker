require('./build.js');
require('./clean.js');
require('./copy.js');
require('./watch.js');
require('./webpack.js');
