import React from 'react';

const ColorImpairedContext = React.createContext(false);
export const ColorImpairedConsumer = ColorImpairedContext.Consumer;

export default ColorImpairedContext;
