import React from 'react';
import styles from './MenuItemSeparator.css';

function MenuItemSeparator() {
  return (
    <div className={styles.separator} />
  );
}

export default MenuItemSeparator;
