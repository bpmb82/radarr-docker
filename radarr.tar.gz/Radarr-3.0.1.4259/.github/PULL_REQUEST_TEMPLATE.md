#### Database Migration
YES | NO

#### Description

#### Screenshot (if UI related)

#### Todos
- [ ] Tests
- [ ] Translation Keys
- [ ] Wiki Updates

#### Issues Fixed or Closed by this PR

* Fixes #XXXX
